/**************************************************************************
 *              Copyright (C), AirM2M Tech. Co., Ltd.
 *
 * Name:    platform_fs.h
 * Author:  liweiqiang
 * Version: V0.1
 * Date:    2012/11/27
 *
 * Description:
 * 
 **************************************************************************/

#ifndef __PLATFORM_FS_H__
#define __PLATFORM_FS_H__

const DM_DEVICE* platform_fs_init(void);

#endif //__PLATFORM_FS_H__

