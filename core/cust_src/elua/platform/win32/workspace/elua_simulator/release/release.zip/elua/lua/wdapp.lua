
require"pinop"
module(...,package.seeall)

local function change()
	watchdog.kick()
	sys.timer_start(change,1000)
end

sys.timer_start(change,1000)

watchdog.open(watchdog.DEFAULT,pins.def.WATCHDOG.pin)
