-- PC��̴���
require"sys"
require"nvm"
require"pinop"
require"led"
module(...,package.seeall)

local PROGRAM_TIMEOUT=120000 -- ��̳�ʱʱ��2����
local mode = 0

function inprogram()
	return mode > 0
end

local function setinstaller(id,s)
	if string.len(s) ~= 6 or string.match(s,"(%d+)") ~= s then
		print("setinstaller:invalid",s)
		return false
	end

	nvm.set("installer",s)
	return true
end

local function setalarmnum(id,s)
	if s ~= "" and (string.len(s) < 8 or string.len(s) > 16 or string.match(s,"(%d+)") ~= s) then
		print("setalarmnum:invalid",s)
		return false
	end

	nvm.set("alarmnum",id,s)
	return true
end

local function setopcode(id,s)
	if string.len(s) ~= 4 or string.match(s,"(%d+)") ~= s then
		print("setopcode:invalid",s)
		return false
	end

	nvm.set("opcode",s)
	return true
end

local function setadmin(id,s)
	if s ~= "" and (string.len(s) < 8 or string.len(s) > 16 or string.match(s,"(%d+)") ~= s) then
		print("setadmin:invalid",s)
		return false
	end

	nvm.set("admin",id-7+1,s)
	return true
end

local function setalarmode(id,s)
	if string.len(s) ~= 5 or string.match(s,"([012]+)") ~= s then
		print("setalarmode:invalid",s)
		return false
	end

	for i=1,string.len(s) do
		nvm.set("alarmode",i,tonumber(string.sub(s,i,i)))
	end

	return true
end

local function setcallrepeat(id,s)
	if string.len(s) ~= 2 or tonumber(s) == nil or tonumber(s) >= 10 then
		return false
	end

	nvm.set("callrepeat",tonumber(s))
	return true
end

local function getwdevnvid(cid,text)
	local nvid = cid < 50 and cid or cid-50
	local nvname

	if nvid == 28 then
		nvname = "wdef5"
		if text == nil or string.len(text) ~= 1 then
			print("access.getwdevnvid: invalid",text)
			return
		end
		nvid = tonumber(text)
	elseif nvid >= 20 and nvid <= 23 then
		nvname = "ctrler"
		nvid = nvid-20+1
	else
		nvname = "wdef"
		nvid = nvid-24+1
	end

	return nvname,nvid
end

local currcmd = nil
local currtext = nil

local function learnctrltimeout()
	currcmd = nil
	rmtctler.exitlearn()
	uart.write(3,"ERROR")
end

function ctrlerlearn(ctrlid)
	if currcmd and currcmd >= 20 and currcmd <= 28 then
		sys.timer_stop(learnctrltimeout)

		local nvname,nvid = getwdevnvid(currcmd,currtext)
		nvm.set(nvname,nvid,ctrlid)
		currcmd = nil
		currtext = nil
		uart.write(3,tostring(ctrlid))
	end
end

local function setctrler(id,text)
	-- �ظ���ǰ��¼��ң����������
	local nvname,nvid = getwdevnvid(id,text)

	if nvname == nil then return false end

	local code = nvm.get(nvname,nvid)

	if id == 28 then
		currtext = text
		uart.write(3,string.format("%sA%s",id..text,code >= 0x10000 and "-" or code))
	else
		currtext = nil
		uart.write(3,string.format("%dA%s",id,code >= 0x10000 and "-" or code))
	end

	--������ң����ѧϰ
	currcmd = id
	rmtctler.enterlearn()
	sys.timer_start(learnctrltimeout,15000)
	return "PROCEEDING"
end

local function setalarmtext(id,text)
	if text == "" then -- ���������������������
		print("setalarmtext:invalid")
		return false
	end

	nvm.set("alarmtext",id-30+1,text)
	return true
end

local function setdef2valid(id,text)
	if text == "��ͨ" or text == "����" then
		nvm.set("def2valid",text)
		return true
	end

	return false
end

local function setdefstat(id,text)
	if text == "��·" or text == "��·" then
		nvm.set(id == 36 and "def4stat" or "def5stat",text)
		return true
	end

	return false
end

local function setslalarmtime(id,s)
	if string.len(s) ~= 2 or string.match(s,"(%d+)") ~= s then
		print("setslalarmtime:invalid",s)
		return false
	end

	nvm.set("slalarmtime",tonumber(s)*1000)
	return true
end

local function setaccalertime(id,s)
	if string.len(s) ~= 2 or string.match(s,"(%d+)") ~= s then
		print("setaccalertime:invalid",s)
		return false
	end

	nvm.set("accalertime",tonumber(s)*1000)
	return true
end

local function setsidelvl(id,s)
	if not (s == "0" or s == "1") then
		print("setsidelvl:invalid",s)
		return false
	end

	nvm.set("sidelvl",bit.bxor(tonumber(s),0x01))
	pins.def.SIDE_IN_INT.valid = nvm.get("sidelvl")
	return true
end

local function settrunklvl(id,s)
	if not (s == "0" or s == "1") then
		print("settrunklvl:invalid",s)
		return false
	end

	nvm.set("trunklvl",bit.bxor(tonumber(s),0x01))
	pins.def.TRUNK_IN_INT.valid = nvm.get("trunklvl")
	return true
end

local function settrunkoutlvl(id,s)
	if not (s == "0" or s == "1") then
		print("settrunkoutlvl:invalid",s)
		return false
	end

	nvm.set("trunkoutlvl",tonumber(s))

	pins.setrunkoutvalid(nvm.get("trunkoutlvl"))

	return true
end

local function settrunkoutime(id,s)
	if string.len(s) ~= 2 or string.match(s,"(%d+)") ~= s then
		print("settrunkoutime:invalid",s)
		return false
	end

	local tms = tonumber(s)

	if tms < 1 or tms > 30 then
		print("settrunkoutime:invalid",s)
		return false
	end

	nvm.set("trunkoutime",tms*1000)
	return true
end

local function getinstaller(id)
	uart.write(3,string.format("%dA%s",id,nvm.get("installer")))
end

local function getalarmnum(id)
	local str = nvm.get("alarmnum",id-51+1)
	uart.write(3,string.format("%dA%s",id,str == "" and "-" or str))
end

local function getopcode(id)
	uart.write(3,string.format("%dA%s",id,nvm.get("opcode")))
end

local function getadmin(id)
	local str = nvm.get("admin",id-57+1)
	uart.write(3,string.format("%dA%s",id,str == "" and "-" or str))
end

local function getalarmode(id)
	uart.write(3,string.format("%dA%s",id,table.concat(nvm.get("alarmode"))))
end

local function getcallrepeat(id)
	uart.write(3,string.format("%dA%s",id,nvm.get("callrepeat")))
end

local function getctrler(id,text)
	-- ���ң����
	local nvname,nvid = getwdevnvid(id,text)
	nvm.set(nvname,nvid,0x10000)
	return true
end

local function getalarmtext(id)
	uart.write(3,string.format("%dA%s",id,nvm.get("alarmtext",id-80+1)))
end

local function getdef2valid(id)
	uart.write(3,string.format("%dA%s",id,nvm.get("def2valid")))
end

local function getdefstat(id,text)
	uart.write(3,string.format("%dA%s",id,nvm.get(id == 86 and "def4stat" or "def5stat")))
end

local function getslalarmtime(id)
	local delay = nvm.get("slalarmtime")/1000
	uart.write(3,string.format("%d%02d",id,delay))
end

local function getaccalertime(id)
	local delay = nvm.get("accalertime")/1000
	uart.write(3,string.format("%d%02d",id,delay))
end

local function getsidelvl(id)
	uart.write(3,string.format("%d%d",id,bit.bxor(nvm.get("sidelvl"),0x01)))
end

local function gettrunklvl(id)
	uart.write(3,string.format("%d%d",id,bit.bxor(nvm.get("trunklvl"),0x01)))
end

local function gettrunkoutlvl(id)
	uart.write(3,string.format("%d%d",id,nvm.get("trunkoutlvl")))
end

local function gettrunkoutime(id)
	local delay = nvm.get("trunkoutime")/1000
	uart.write(3,string.format("%d%02d",id,delay))
end

local cmds =
{
	[00] = setinstaller,
	[01] = setalarmnum,
	[02] = setalarmnum,
	[03] = setalarmnum,
	[04] = setalarmnum,
	[05] = setalarmnum,
	[06] = setopcode,
	[07] = setadmin,
	[08] = setadmin,
	[09] = setadmin,
	[10] = setalarmode,
	[11] = setcallrepeat,
	[20] = setctrler,
	[21] = setctrler,
	[22] = setctrler,
	[23] = setctrler,
	[24] = setctrler,
	[25] = setctrler,
	[26] = setctrler,
	[27] = setctrler,
	[28] = setctrler,
	[30] = setalarmtext,
	[31] = setalarmtext,
	[32] = setalarmtext,
	[33] = setalarmtext,
	[34] = setalarmtext,
	[35] = setdef2valid,
	[36] = setdefstat,
	[37] = setdefstat,
	[38] = setslalarmtime,
	[39] = setaccalertime,
	[40] = setsidelvl,
	[41] = settrunklvl,
	[42] = settrunkoutlvl,
	[43] = settrunkoutime,

	[50] = getinstaller,
	[51] = getalarmnum,
	[52] = getalarmnum,
	[53] = getalarmnum,
	[54] = getalarmnum,
	[55] = getalarmnum,
	[56] = getopcode,
	[57] = getadmin,
	[58] = getadmin,
	[59] = getadmin,
	[60] = getalarmode,
	[61] = getcallrepeat,
	[70] = getctrler,
	[71] = getctrler,
	[72] = getctrler,
	[73] = getctrler,
	[74] = getctrler,
	[75] = getctrler,
	[76] = getctrler,
	[77] = getctrler,
	[78] = getctrler,
	[80] = getalarmtext,
	[81] = getalarmtext,
	[82] = getalarmtext,
	[83] = getalarmtext,
	[84] = getalarmtext,
	[85] = getdef2valid,
	[86] = getdefstat,
	[87] = getdefstat,
	[88] = getslalarmtime,
	[89] = getaccalertime,
	[90] = getsidelvl,
	[91] = gettrunklvl,
	[92] = gettrunkoutlvl,
	[93] = gettrunkoutime,
}

local function setalertdelay(id,s)
	if string.len(s) ~= 2 or string.match(s,"(%d+)") ~= s or tonumber(s) == 0 then
		print("setalertdelay:invalid",s)
		return false
	end

	nvm.set("alertdelaytime",tonumber(s)*1000)
	return true
end

local function setrmtcall(id,s)
	if string.len(s) ~= 3 or string.match(s,"(%d+)") ~= s then
		print("setrmtcall:invalid",s)
		return false
	end

	local callrepeat = tonumber(string.sub(s,1,1))
	local callinterval = tonumber(string.sub(s,2,3))

	if not (callrepeat >= 1 and callrepeat <= 9 and callinterval >= 10 and callinterval <= 50) then
		print("setrmtcall:invalid",s)
		return false
	end

	nvm.set("incalltimes",callrepeat)
	nvm.set("incallinterval",callinterval*1000)
	return true
end

local function setautoalertdelay(id,s)
	if string.len(s) ~= 3 or string.match(s,"(%d+)") ~= s or tonumber(s) < 20 then -- ����Ҫ����20��
		print("setautoalertdelay:invalid",s)
		return false
	end

	nvm.set("delayautoalert",tonumber(s)*1000)
	return true
end

local function setstepshutoe(id,s)
	if string.len(s) ~= 3 or string.match(s,"(%d%.%d)") ~= s then -- ֧��С����
		print("setstepshutoe:invalid",s)
		return false
	end

	local num = tonumber(string.sub(s,1,1))*1000 + tonumber(string.sub(s,3,3))*100

	if num > 8000 or num < 1000 then
		print("setstepshutoe:invalid",num)
		return false
	end

	nvm.set("stepshutoe",num)
	return true
end

local function setmidlocktime(id,s)
	if string.len(s) ~= 3 or string.match(s,"(%d%.%d)") ~= s then -- ֧��С����
		print("setmidlocktime:invalid",s)
		return false
	end

	local num = tonumber(string.sub(s,1,1))*1000 + tonumber(string.sub(s,3,3))*100

	if num > 10000 or num < 200 then
		print("setmidlocktime:invalid",num)
		return false
	end

	nvm.set("midlocktime",num)
	return true
end

local function getalertdelay(id)
	local delay = nvm.get("alertdelaytime")/1000
	uart.write(3,string.format("%d%02d",id,delay))
end

local function getrmtcall(id)
	uart.write(3,string.format("%d%d%02d",id,nvm.get("incalltimes"),nvm.get("incallinterval")/1000))
end

local function getautoalertdelay(id)
	local delay = nvm.get("delayautoalert")/1000
	uart.write(3,string.format("%d%03d",id,delay))
end

local function getstepshutoe(id)
	local delay = nvm.get("stepshutoe")

	local s = delay/1000 .. "." .. (delay%1000)/100

	uart.write(3,id .. s)
end

local function getmidlocktime(id)
	local delay = nvm.get("midlocktime")

	local s = delay/1000 .. "." .. (delay%1000)/100

	uart.write(3,id .. s)
end

local hidecmds =
{
	[15] = setmidlocktime,
	[16] = setstepshutoe,
	[17] = setautoalertdelay,
	[18] = setalertdelay,
	[19] = setrmtcall,
	[65] = getmidlocktime,
	[66] = getstepshutoe,
	[67] = getautoalertdelay,
	[68] = getalertdelay,
	[69] = getrmtcall,
}

local function timeout()
	mode = 0
	uart.write(3,"EXIT")
	led.work("programend")
end

local function parse(s)
	if s == "99" then
		uart.write(3,"OK")
		nvm.restore()
		return
	end

	if mode == 0 then
		if s == nvm.get("installer") or s == "737737" then
			mode = s == "737737" and 2 or 1
			uart.write(3,"OK")
			led.work("blink")
			sys.timer_start(timeout,PROGRAM_TIMEOUT)
		else
			uart.write(3,"ERROR")
		end
		return
	end

	if mode > 0 then
		if s == "*#" then
			mode = 0
			if currcmd then
				if currcmd >= 20 and currcmd <= 28 then
					sys.timer_stop(learnctrltimeout)
					rmtctler.exitlearn()
				end
				currcmd = nil
			end
			uart.write(3,"OK")
			sys.timer_stop(timeout)
			led.work("programend")
			return
		end
	end

	sys.timer_start(timeout,PROGRAM_TIMEOUT)

	if currcmd ~= nil then
		uart.write(3,"ERROR") -- �����������ڴ���,������������һ������
		return
	end

	local id = tonumber(string.sub(s,1,2))

	if id == nil then
		print("unknwon cmd:",s)
		return
	end

	local proc = cmds[id]

	if proc == nil and mode == 2 then
		proc = hidecmds[id]
	end

	if proc ~= nil then
		local result = proc(id,string.sub(s,3,-1))

		if result == "PROCEEDING" then
			currcmd = id
		elseif result == true then
			uart.write(3,"OK")
		elseif result == false then
			uart.write(3,"ERROR")
		end
	else
		uart.write(3,"ERROR")
	end
end

local function recv()
	local s

	while true do
		s = uart.read(3,"*l")

		if string.len(s) == 0 then
			break
		end

		parse(s)
	end
end
sys.reguart(3,recv)
uart.setup(3,921600,8,uart.PAR_NONE,uart.STOP_1,2)
